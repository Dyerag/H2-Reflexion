CREATE LOGIN FilmProvider with password = 'P@ssw0rd', default_database = Filmdb
GO

CREATE LOGIN FilmManager with password = 'P@ssw0rd', default_database = Filmdb
go